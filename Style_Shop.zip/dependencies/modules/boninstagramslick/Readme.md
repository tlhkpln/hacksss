Easy Instagram Carousel Social Feed Photos


Description:
The «Easy Instagram» module can display an Instagram image from a single Instagram user’s
photo collection or from images throughout Instagram hashtagged with a specified Tag.

Benefits for Merchants:
Module is easy way to integrate your Instagram photos/feeds into your site.
It can also create a gallery fed either from the Instagram User ID or the Tag.

This easy at installation and flexible at configuration module allows you to create attractive Easy Instagram Carousel Social Feed Photos in a couple of minutes!

Features:

Super easy install and customize.
Simple and friendly user interface.
Get feeds by tagget or user.
For your own photos or a #hashtag feed.
The module is multiform compatible.
Display main, category, product page, CMS pages, etc.
Compatible with all web browsers.
Multi-language and multi-store ready.
Support and well documented.

instagram, images, hashtag, feed, carousel, slider, user, tagget, feeds, media, social, photo, gallery, widget, responsive
