<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{bonnewsletter}prestashop>ajax_e267e2be02cf3e29f4ba53b5d97cf78a'] = ' Invalid YOUR';
