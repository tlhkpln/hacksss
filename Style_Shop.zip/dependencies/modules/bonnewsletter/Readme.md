Advanced Newsletter Popup

Short Description:
This module allows you to display a newsletter popup with a custom message on your store's home page screen when customers visit your site.

Benefits for Merchants:
Advanced Newsletter Popup is a professional marketing tool, designed to grow your email subscriber list. 
With the addition of the newsletter pop-up, new users to your website can subscribe to your store's newsletter by simply submitting their email IDs. 
Once the user clicks 'Submit', the email gets registered and thereafter the user can receive sale-related newsletters and emails. 
All growing businesses or services need to increase their popularity and reach their audience on a regular basis. 

Install:

This easy at installation and flexible at configuration module allows you to create attractive Advanced Newsletter Popup in a couple of minutes!

Features:

Super easy install and customize.
Get more subscribers for your store.
Selecting the display period time.
Change time and animation speed display popup.
Set width and height for popup.
Set animation type: fade, slide, none.
Change background and opacity for back popup.
Display animation effects.
Simple and Friendly user interface.
Compatible with all web browsers.
Multi-language and Multi-store ready.
Support and well documented.

advertising, popup, banner, notification, custom, newsletter, images, subscription, animation, products, message, promotional, promotion, customers, email