/**
 * 2015-2021 Bonpresta
 *
 * Bonpresta Text Banner with Carousel
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the General Public License (GPL 2.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/GPL-2.0
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade the module to newer
 * versions in the future.
 *
 *  @author    Bonpresta
 *  @copyright 2015-2021 Bonpresta
 *  @license   http://opensource.org/licenses/GPL-2.0 General Public License (GPL 2.0)
 */

$(document).ready(function () {
  $('.slick-carousel-bontextslider').slick({
    infinite: true,
    autoplaySpeed: BON_TEXT_SLIDER_TIME,
    draggable: false,
    dots: false,
    arrows: false,
    autoplay: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    vertical: true
  });

  BontextsliderClose();
});

function BontextsliderClose() {
  let BonLocalSlider = JSON.parse(localStorage.getItem('BonLocalSlider'));
  if ($('#bontextslider').hasClass('active')) {
    $('#bontextslider').removeClass('active').scrollTop(0);
  }

  if (BonLocalSlider === 'close') {
    $('#bontextslider').addClass('active');
  }

  $('#bontextslider-close').on('click', function () {
    localStorage.setItem('BonLocalSlider', JSON.stringify('close'));
    $('#bontextslider').addClass('active');
  });
}
