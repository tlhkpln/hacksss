
HTML Content


Description:
HTML Content is a module that lets you easily create powerful content with very nice transition effects. Enhance your website by adding a unique and attractive HTML Content!

Benefits for Merchants:
It is an effective tool for advertising to get user's attention on your site.
Most of customers coming to an online store and pay attention to banners first.
Use to attract the attention of your client on your offers.


Features:

Super easy install and customize.
Easy to upload and manage html content
Drag and drop to change positions.
Enable carousel for html content
Embed links and images inside html text description box.
Responsive & Touch enable.
Resize a html content automatically on responsive themes.
Simple and Friendly user interface.
Compatible with all web browsers.
Multi-language and Multi-store ready.
Support and well documented.

content, images, links, carousel, gallery, html, responsive, mobile, tablet, banner, media, advertising, slider, home, banners


<div class="box-icon"><i class="material-icons">directions_car</i></div>
<div class="box-content">
<h3>Free Shipping US</h3>
<h5>On all order over $250</h5>
</div>

<div class="box-icon"><i class="material-icons">loop</i></div>
<div class="box-content">
<h3>Money Guarantee</h3>
<h5>30 day money back</h5>
</div>

<div class="box-icon"><i class="material-icons">credit_card</i></div>
<div class="box-content">
<h3>Payment Secured</h3>
<h5>Secure all your payments</h5>
</div>

<div class="box-icon"><i class="material-icons">call</i></div>
<div class="box-content">
<h3>Power Support</h3>
<h5>Online Support 24/7</h5>
</div>