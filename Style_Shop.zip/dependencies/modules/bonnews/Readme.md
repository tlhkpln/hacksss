News Manager with Videos and Comments

Description:
News Manager with Videos and Comments is a module that lets you easily create powerful banners with very nice transition effects. Enhance your website by adding a unique and attractive banner!

Benefits for Merchants:
Most of customers coming to an online store and pay attention to banners first. Banner Slider is most effective way to show a series of your images, content, and call to action button.
It is an effective tool for advertising to get user's attention on your site.
This module includes unlimited banner sliders, multiple slider styles, easy configuration, sort order of banners, short-code for CMS/HTML Editor and many more.

Features:

Super easy install and customize.
Easy to upload and manage banners
Drag and drop to change positions.
Set navigation and pagination.
Embed links and images inside html text description box.
Add direct URLs to each image.
Drag and drop to change positions.
Responsive & Touch enable.
Resize a banner automatically on responsive themes.
Simple and Friendly user interface.
Compatible with all web browsers.
Multi-language and Multi-store ready.
Support and well documented.

video, images, links, carousel, gallery, html, responsive, mobile, tablet, banner, media, advertising, slider, home, banners

<h3>Jewelry</h3>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has</p>
<p><span>SHOP NOW</span></p>

<h3>Watches</h3>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has</p>
<p><span>SHOP NOW</span></p>

<h3>SUNGLASSES</h3>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has</p>
<p><span>SHOP NOW</span></p>

<h3>HATS</h3>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has</p>
<p><span>SHOP NOW</span></p>

<h3>Shoes</h3>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has</p>
<p><span>SHOP NOW</span></p>

<h3>Bags</h3>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has</p>
<p><span>SHOP NOW</span></p>
