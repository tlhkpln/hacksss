Awesome Image Slider

Description:

Awesome Image Slider is a module that lets you easily create powerful sliders with very nice transition effects. 
Enhance your website by adding a unique and attractive slider!

Benefits for Merchants:

Display banner slideshow to attract customers.
Awesome Image Slider with various settings to control every aspect of your slideshow, including transitions, directions, sliding speeds and pagination controls.
The module allows you to insert an unlimited number of sliders to any place of your store.
It is also touch sensitive, so you can swipe the image slide on all device.


This easy at installation and flexible at configuration module allows you to create attractive Awesome Image Slider in a couple of minutes!


Features:

Super easy install and customize.
Set autoplay and mouse drag.
Set navigation and pagination.
Set autoplay timeout.
Add direct urls to each image.
Drag and drop to change positions.
Responsive & Touch enable.
Resize a slider automatically on responsive themes.
Simple and friendly user interface.
Compatible with all web browsers.
Multi-language and multi-store ready.
Support and well documented.



slider, images, links, carousel, gallery, html, responsive, mobile, tablet, banner, media, advertising, slider, home, banners


<h3>New Arrivals</h3>
<h1>i-Mac 5k retina display</h1>
<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed perspiciatis unde omnis iste natus error sit voluptatem.</p>
<p><span>SHOP NOW</span></p>

<h3>Featured</h3>
<h1>Buy iPad 9.7-inch - Apple</h1>
<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed perspiciatis unde omnis iste natus error sit voluptatem.</p>
<p><span>SHOP NOW</span></p>

<h3>New collection</h3>
<h1>iPhone 7</h1>
<p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed perspiciatis unde omnis iste natus error sit voluptatem.</p>
<p><span>SHOP NOW</span></p>