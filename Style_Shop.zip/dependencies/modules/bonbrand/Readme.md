Brand Manager


Description:
This module is an easy-to-use module that shows manufacturer logo on product and category page. Manufacturer logo slider box to your shop homepage.

Merchants:

Brands are a guarantee for quality, they assure product recognition in customers.
Is essential to work with product brands for increase sales and generate reliability on your e-commerce site.
With this extension you can add product brands to your shop.
Clicks will filter products to selected manufacturer.
Carousel is fully controlled in admin.


Install:

This easy at installation and flexible at configuration module allows you to create attractive countdown timers in a couple of minutes!


Features:
Super easy install and customize.
Easy selection of displaying brands.
Show manufacturer logo as list or carousel.
Very easy to integrate into your shop.
Many options to customize.
Configure size of displaying logos.
Click on a logo to get in products list.
Order by manufacturer name or id.
Display logo on product and category page.
Fully responsive 100%.
Multi-language and Multi-store ready.
Cross browser compatible.
Support and well documented.



Tag:

brand, manufacturer, carousel, responsive, slider, brands, logos, product, category, manufacturers, brand, manager, logo, page, partners