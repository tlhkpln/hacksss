Promotion Discount Countdown Banner & Slider


Description:

This is super easy to use module that allows you to display promotion countdown banner or slider into homepage and other pages.

Benefits for Merchants:

It is an effective tool for advertising to get user's attention on your site.
Enhance your website by adding a unique and attractive banner!
The ticking timer is a useful feature to terminate your product sales, and it is also a perfect motivator.
Slider is designed for displaying full-size sliders on any of your website pages.

Features:

Super easy install and customize.
Easy to upload and manage banners
Embed links and images inside html text description box.
Add direct URLs to each image.
Drag and drop to change positions.
Set navigation and pagination.
Responsive & Touch enable.
Resize a banner automatically on responsive themes.
Simple and Friendly user interface.
Compatible with all web browsers.
Multi-language and Multi-store ready.
Support and well documented.



video, images, timer, carousel, gallery, html, countdown, mobile, promotion, banner, media, advertising, slider, home, banners


<h3>Fashion Collection</h3>
<h2>Limited Discount</h2>