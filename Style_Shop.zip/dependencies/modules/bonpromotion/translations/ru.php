<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{bonpromotion}prestashop>bonpromotion_44fdec47036f482b68b748f9d786801b'] = ' %дней';
$_MODULE['<{bonpromotion}prestashop>promotion-front_9a407ad22184c967a318f6ae2ea79581'] = 'Купить сейчас!';
