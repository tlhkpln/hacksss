WhatsApp Chat


Short Description:
WhatsApp Contact Button allows you to start a WhatsApp chat directly from your shop.


Benefits for Merchants:
An online chat system provides visitors, readers, customers immediate access to help.
Wait times are often much less than a call center, and visitors, readers, customers can easily multi-task while waiting.
One button and a conversation with you will open automatically. Let all your customers contact you immediately and stop losing potential leads !
Concept about a WhatsApp contact button for websites that can be used as an alternative way of communication. Instead of calling a phone, email or SMS, just send a WhatsApp message.

Install:

This easy at installation and flexible at configuration module allows you to create attractive WhatsApp Chat in a couple of minutes!

Features:

Super easy install and customize.
Change color button.
5 animation effects.
Automatically detect mobile to redirect to WhatsApp.
Custom your message to start chat.
Simple and Friendly user interface.
Compatible with all web browsers.
Multi-language and Multi-store ready.
Support and well documented.

whatsapp, chat, message, message, support, seo, analytics, monitor, widget, visitors, client, social, contact, phone, customers