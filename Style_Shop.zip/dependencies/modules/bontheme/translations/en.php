<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_083ff21e748c48e0c378a7c3e8dd4fa5'] = 'WhatsApp Chat';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_912d2b8b74d69879b4e416f0644862b7'] = 'Display whatsapp chat.';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_a7cc289efab9e5c372422d3fa0a98904'] = 'Save all settings.';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_0099c0173a3c7758b36025bdae9b4fc7'] = 'Enable:';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_93cba07454f06a4a960172bbd6e2a435'] = 'Yes';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_cec59c4cf319e37788de60170226b705'] = 'Mobile phone:';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_ec16e90b650301f5d0e870f03a1b8e3c'] = 'Position:';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_945d5e233cf7d6240f6b783b36a374ff'] = 'Left';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_92b09c7c48c520c3c55e497875da437c'] = 'Right';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_b8a41ccad58aaf09b926bc1b4f38e57a'] = 'Background button:';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_fa20e88573ea59fba619fb728edb1bea'] = 'Animation:';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_04a5411dd8c9a2cbfacf479dfd20fa21'] = 'Tada';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_198b44a40aa77f2256886010c7526c0b'] = 'Swing';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_8d2de5368588552fbae54044ac5c7b3d'] = 'Rotate';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_f285bec73b34c6b77026c180aae0e5ba'] = 'Buzz';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_b3263eb38f8903efc271cc7a760da510'] = 'Backward';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_ad0a32a319f287b98e907642ddfa2c7d'] = 'The id phone required.';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_32a6eab2994d9509d994162ea1fdf185'] = 'Bad phone format';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_f830709a91cf8a9f5ab848eb9fe8331f'] = '\"Background button\" format error.';
$_MODULE['<{bonwhatsapp}prestashop>bonwhatsapp_8b777ebcc5034ce0fe96dd154bcb370e'] = 'WhatsApp';
