Responsive Banner Images

Short Description:
This module is a highly advanced banner ad management and sales tool. Setting up and managing your banners has never been this easy!


Benefits for Merchants:
Create or delete banners, possibility to enable or disable banners. You can choose different images and links for each language.
Banners are controlled through PrestaShop admin panel. Professional banners module supports responsive banners and mobile


Features:
You can add text, title and link to your banner.
Add different images for each language
Add, edit, delete banner
Change banners status
Drag and Drop to change positions
Banners optimized for SEO with title and description.
Images adaptable to all devices.
Fully responsive 100%.
Multi-language ready.
Support Multi-Store.
Well documented.