<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{zendeskchat}prestashop>zendeskchat_1370601638501ffb1a68deaf180dddeb'] = 'Chat en ligne Zendesk';
$_MODULE['<{zendeskchat}prestashop>zendeskchat_db8c0ee473178c9909a96771e798409b'] = 'Afficher le chat en ligne Zendesk.';
$_MODULE['<{zendeskchat}prestashop>zendeskchat_a7cc289efab9e5c372422d3fa0a98904'] = 'Enregistrez tous les paramètres.';
$_MODULE['<{zendeskchat}prestashop>zendeskchat_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{zendeskchat}prestashop>zendeskchat_03de54fcf64aec3b7d1109e0ab571319'] = 'Zendesk Id:';
$_MODULE['<{zendeskchat}prestashop>zendeskchat_c9cc8cce247e49bae79f15173ce97354'] = 'Sauvegarder';
$_MODULE['<{zendeskchat}prestashop>zendeskchat_bfd68854e00eeff44d2f004730244df2'] = 'L\'identifiant est requis.';
